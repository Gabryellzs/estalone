"use client"

import { useState, useEffect, useRef } from "react"

export function useLocalStorage<T>(key: string, initialValue: T) {
  // Referência para verificar se é a primeira renderização
  const isFirstRender = useRef(true)

  // Estado para armazenar o valor
  const [storedValue, setStoredValue] = useState<T>(initialValue)

  // Inicializa o estado com o valor do localStorage (se existir)
  useEffect(() => {
    // Só executamos a leitura do localStorage na primeira renderização
    if (isFirstRender.current) {
      try {
        // Verifica se estamos no navegador (não no servidor)
        if (typeof window !== "undefined") {
          const item = window.localStorage.getItem(key)
          // Analisa o item armazenado ou retorna o valor inicial
          if (item) {
            setStoredValue(JSON.parse(item))
          }
        }
      } catch (error) {
        console.error(`Erro ao carregar ${key} do localStorage:`, error)
      }
      isFirstRender.current = false
    }
  }, [key, initialValue])

  // Função para atualizar o valor no localStorage
  const setValue = (value: T | ((val: T) => T)) => {
    try {
      // Permite que o valor seja uma função (como em setState)
      const valueToStore = value instanceof Function ? value(storedValue) : value

      // Salva o estado
      setStoredValue(valueToStore)

      // Salva no localStorage
      if (typeof window !== "undefined") {
        window.localStorage.setItem(key, JSON.stringify(valueToStore))
      }
    } catch (error) {
      console.error(`Erro ao salvar ${key} no localStorage:`, error)
    }
  }

  return [storedValue, setValue] as const
}
