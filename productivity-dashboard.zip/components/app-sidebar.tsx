"use client"

import type React from "react"

import { useState } from "react"
import {
  Calendar,
  CreditCard,
  FileText,
  Home,
  LayoutDashboard,
  MessageSquare,
  Moon,
  Package,
  Pencil,
  Sun,
  Network,
} from "lucide-react"
import { useTheme } from "@/hooks/use-theme"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

// Importe o hook useLocalStorage
import { useLocalStorage } from "@/hooks/use-local-storage"

type ViewType = "dashboard" | "diary" | "notes" | "calendar" | "products" | "message" | "finances" | "mindmap"

interface AppSidebarProps {
  onViewChange: (view: ViewType) => void
  activeView: ViewType
}

export function AppSidebar({ onViewChange, activeView }: AppSidebarProps) {
  const { theme, toggleTheme } = useTheme()
  const [customName, setCustomName] = useLocalStorage<string>("app-custom-name", "Minha Central")
  const [isEditing, setIsEditing] = useState(false)
  const [inputValue, setInputValue] = useState(customName)

  const handleStartEditing = () => {
    setInputValue(customName)
    setIsEditing(true)
  }

  const handleSaveName = () => {
    if (inputValue.trim()) {
      setCustomName(inputValue)
    }
    setIsEditing(false)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSaveName()
    } else if (e.key === "Escape") {
      setIsEditing(false)
    }
  }

  // Vamos modificar o array menuItems para reposicionar o "Mapa Mental" logo após o "Dashboard"

  const menuItems = [
    {
      id: "dashboard" as ViewType,
      title: "Dashboard",
      icon: LayoutDashboard,
    },
    {
      id: "mindmap" as ViewType,
      title: "Mapa Mental",
      icon: Network,
    },
    {
      id: "diary" as ViewType,
      title: "Diário",
      icon: Home,
    },
    {
      id: "notes" as ViewType,
      title: "Anotações do Dia a Dia",
      icon: FileText,
    },
    {
      id: "calendar" as ViewType,
      title: "Calendário",
      icon: Calendar,
    },
    {
      id: "products" as ViewType,
      title: "Criação de Produtos",
      icon: Package,
    },
    {
      id: "message" as ViewType,
      title: "Mensagem do Dia",
      icon: MessageSquare,
    },
    {
      id: "finances" as ViewType,
      title: "Financeiro",
      icon: CreditCard,
    },
  ]

  return (
    <Sidebar>
      <SidebarHeader className="flex flex-col items-center justify-center p-4">
        <h1 className="text-xl font-bold">BLACK's</h1>
        {isEditing ? (
          <div className="flex items-center mt-1">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onBlur={handleSaveName}
              onKeyDown={handleKeyDown}
              className="h-7 text-sm"
              autoFocus
            />
          </div>
        ) : (
          <div className="flex items-center mt-1">
            <span className="text-sm text-muted-foreground">{customName}</span>
            <Button variant="ghost" size="icon" className="h-5 w-5 ml-1" onClick={handleStartEditing}>
              <Pencil className="h-3 w-3" />
            </Button>
          </div>
        )}
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Menu</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton isActive={activeView === item.id} onClick={() => onViewChange(item.id)}>
                    <item.icon className="h-4 w-4" />
                    <span>{item.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter>
        <SidebarGroup>
          <SidebarGroupLabel>Configurações</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton onClick={toggleTheme}>
                  {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                  <span>Tema: {theme === "dark" ? "Escuro" : "Claro"}</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
