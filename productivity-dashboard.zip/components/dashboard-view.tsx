"use client"
import { Calendar, CreditCard, FileText, LineChart, MessageSquare, Package, Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Progress } from "@/components/ui/progress"

// Importe o hook useLocalStorage
import { useLocalStorage } from "@/hooks/use-local-storage"

interface DashboardProps {
  onViewChange: (view: string) => void
}

// Tipos para os widgets da dashboard
interface Widget {
  id: string
  type: "finance" | "notes" | "events" | "message" | "products" | "transactions"
  title: string
  pinned: boolean
}

export default function DashboardView({ onViewChange }: DashboardProps) {
  // Substitua as linhas:
  // const [widgets, setWidgets] = useState<Widget[]>([])
  // const [showWelcome, setShowWelcome] = useState(true)

  // Por:
  const [widgets, setWidgets] = useLocalStorage<Widget[]>("dashboard-widgets", [])
  const [showWelcome, setShowWelcome] = useLocalStorage<boolean>("dashboard-show-welcome", true)

  // Dados simulados para os widgets
  const financialData = {
    balance: 3250.75,
    income: 5200.0,
    expenses: 1949.25,
    recentTransactions: [
      { id: 1, description: "Pagamento Cliente", amount: 1200, type: "income", date: "Hoje" },
      { id: 2, description: "Aluguel", amount: 800, type: "expense", date: "Ontem" },
      { id: 3, description: "Freelance", amount: 450, type: "income", date: "22/04/2025" },
    ],
  }

  const recentNotes = [
    { id: 1, title: "Ideias para novo projeto", preview: "Desenvolver um aplicativo que...", date: "Hoje" },
    { id: 2, title: "Reunião com cliente", preview: "Pontos a discutir: orçamento, prazo...", date: "Ontem" },
  ]

  const upcomingEvents = [
    { id: 1, title: "Reunião de equipe", date: "Hoje, 15:00" },
    { id: 2, title: "Entrega do projeto", date: "Amanhã, 10:00" },
    { id: 3, title: "Consulta médica", date: "26/04/2025, 14:30" },
  ]

  const dailyMessage = "Acredite em você mesmo e todo o resto se encaixará. Tenha fé em seus próprios talentos."

  const productStats = {
    total: 5,
    inProgress: 2,
    completed: 3,
    products: [
      { name: "Produto A", progress: 75 },
      { name: "Produto B", progress: 32 },
      { name: "Produto C", progress: 89 },
    ],
  }

  // Função para adicionar um widget à dashboard
  const addWidget = (type: Widget["type"]) => {
    const newWidget: Widget = {
      id: `${type}-${Date.now()}`,
      type,
      title: getWidgetTitle(type),
      pinned: true,
    }

    setWidgets([...widgets, newWidget])
    setShowWelcome(false)
  }

  // Função para remover um widget da dashboard
  const removeWidget = (id: string) => {
    setWidgets(widgets.filter((widget) => widget.id !== id))
    if (widgets.length <= 1) {
      setShowWelcome(true)
    }
  }

  // Função para obter o título do widget com base no tipo
  const getWidgetTitle = (type: Widget["type"]): string => {
    switch (type) {
      case "finance":
        return "Resumo Financeiro"
      case "notes":
        return "Anotações Recentes"
      case "events":
        return "Próximos Eventos"
      case "message":
        return "Mensagem do Dia"
      case "products":
        return "Progresso dos Produtos"
      case "transactions":
        return "Transações Recentes"
      default:
        return "Widget"
    }
  }

  // Função para renderizar o conteúdo do widget com base no tipo
  const renderWidgetContent = (widget: Widget) => {
    switch (widget.type) {
      case "finance":
        return (
          <div className="grid gap-4 grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Saldo Total</CardTitle>
                <CreditCard className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {financialData.balance.toLocaleString("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  })}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Receitas</CardTitle>
                <CreditCard className="h-4 w-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-500">
                  {financialData.income.toLocaleString("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  })}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Despesas</CardTitle>
                <CreditCard className="h-4 w-4 text-red-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-500">
                  {financialData.expenses.toLocaleString("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        )
      case "notes":
        return (
          <div className="space-y-4">
            {recentNotes.map((note) => (
              <div key={note.id} className="border rounded-lg p-3">
                <div className="font-medium">{note.title}</div>
                <div className="text-sm text-muted-foreground mt-1">{note.preview}</div>
                <div className="text-xs text-muted-foreground mt-2">{note.date}</div>
              </div>
            ))}
            <Button variant="outline" className="w-full" onClick={() => onViewChange("notes")}>
              Ver Todas as Anotações
            </Button>
          </div>
        )
      case "events":
        return (
          <div className="space-y-4">
            {upcomingEvents.map((event) => (
              <div key={event.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="rounded-full p-2 bg-primary/20">
                    <Calendar className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{event.title}</p>
                    <p className="text-xs text-muted-foreground">{event.date}</p>
                  </div>
                </div>
              </div>
            ))}
            <Button variant="outline" className="w-full" onClick={() => onViewChange("calendar")}>
              Ver Calendário Completo
            </Button>
          </div>
        )
      case "message":
        return (
          <div className="space-y-4">
            <div className="text-center italic p-4 bg-primary/5 rounded-md">"{dailyMessage}"</div>
            <Button variant="outline" className="w-full" onClick={() => onViewChange("message")}>
              <MessageSquare className="mr-2 h-4 w-4" />
              Atualizar Mensagem
            </Button>
          </div>
        )
      case "products":
        return (
          <div className="space-y-4">
            {productStats.products.map((product, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div>{product.name}</div>
                  <div>{product.progress}%</div>
                </div>
                <Progress value={product.progress} />
              </div>
            ))}
            <Button variant="outline" className="w-full" onClick={() => onViewChange("products")}>
              Gerenciar Produtos
            </Button>
          </div>
        )
      case "transactions":
        return (
          <div className="space-y-4">
            {financialData.recentTransactions.map((transaction) => (
              <div key={transaction.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div
                    className={`rounded-full p-2 ${transaction.type === "income" ? "bg-green-500/20" : "bg-red-500/20"}`}
                  >
                    <CreditCard
                      className={`h-4 w-4 ${transaction.type === "income" ? "text-green-500" : "text-red-500"}`}
                    />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{transaction.description}</p>
                    <p className="text-xs text-muted-foreground">{transaction.date}</p>
                  </div>
                </div>
                <div
                  className={`text-sm font-medium ${transaction.type === "income" ? "text-green-500" : "text-red-500"}`}
                >
                  {transaction.type === "income" ? "+" : "-"}
                  {transaction.amount.toLocaleString("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  })}
                </div>
              </div>
            ))}
            <Button variant="outline" className="w-full" onClick={() => onViewChange("finances")}>
              Ver Todas as Transações
            </Button>
          </div>
        )
      default:
        return <div>Conteúdo não disponível</div>
    }
  }

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Adicionar Widget
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Widget</DialogTitle>
              <DialogDescription>Escolha um widget para adicionar à sua dashboard.</DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-4 py-4">
              <Button
                variant="outline"
                className="h-24 flex flex-col items-center justify-center"
                onClick={() => {
                  addWidget("finance")
                  document.querySelector("[data-state='open']")?.setAttribute("data-state", "closed")
                }}
              >
                <CreditCard className="h-8 w-8 mb-2" />
                <span>Resumo Financeiro</span>
              </Button>
              <Button
                variant="outline"
                className="h-24 flex flex-col items-center justify-center"
                onClick={() => {
                  addWidget("notes")
                  document.querySelector("[data-state='open']")?.setAttribute("data-state", "closed")
                }}
              >
                <FileText className="h-8 w-8 mb-2" />
                <span>Anotações Recentes</span>
              </Button>
              <Button
                variant="outline"
                className="h-24 flex flex-col items-center justify-center"
                onClick={() => {
                  addWidget("events")
                  document.querySelector("[data-state='open']")?.setAttribute("data-state", "closed")
                }}
              >
                <Calendar className="h-8 w-8 mb-2" />
                <span>Próximos Eventos</span>
              </Button>
              <Button
                variant="outline"
                className="h-24 flex flex-col items-center justify-center"
                onClick={() => {
                  addWidget("message")
                  document.querySelector("[data-state='open']")?.setAttribute("data-state", "closed")
                }}
              >
                <MessageSquare className="h-8 w-8 mb-2" />
                <span>Mensagem do Dia</span>
              </Button>
              <Button
                variant="outline"
                className="h-24 flex flex-col items-center justify-center"
                onClick={() => {
                  addWidget("products")
                  document.querySelector("[data-state='open']")?.setAttribute("data-state", "closed")
                }}
              >
                <Package className="h-8 w-8 mb-2" />
                <span>Progresso dos Produtos</span>
              </Button>
              <Button
                variant="outline"
                className="h-24 flex flex-col items-center justify-center"
                onClick={() => {
                  addWidget("transactions")
                  document.querySelector("[data-state='open']")?.setAttribute("data-state", "closed")
                }}
              >
                <LineChart className="h-8 w-8 mb-2" />
                <span>Transações Recentes</span>
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {showWelcome && widgets.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="rounded-full bg-primary/10 p-6 mb-4">
              <Plus className="h-10 w-10 text-primary" />
            </div>
            <h3 className="text-xl font-medium mb-2">Sua Dashboard está vazia</h3>
            <p className="text-muted-foreground text-center max-w-md mb-6">
              Adicione widgets para personalizar sua dashboard e visualizar as informações mais importantes para você.
            </p>
            <Dialog>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Adicionar Primeiro Widget
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Adicionar Widget</DialogTitle>
                  <DialogDescription>Escolha um widget para adicionar à sua dashboard.</DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-2 gap-4 py-4">
                  <Button
                    variant="outline"
                    className="h-24 flex flex-col items-center justify-center"
                    onClick={() => {
                      addWidget("finance")
                      document.querySelector("[data-state='open']")?.setAttribute("data-state", "closed")
                    }}
                  >
                    <CreditCard className="h-8 w-8 mb-2" />
                    <span>Resumo Financeiro</span>
                  </Button>
                  <Button
                    variant="outline"
                    className="h-24 flex flex-col items-center justify-center"
                    onClick={() => {
                      addWidget("notes")
                      document.querySelector("[data-state='open']")?.setAttribute("data-state", "closed")
                    }}
                  >
                    <FileText className="h-8 w-8 mb-2" />
                    <span>Anotações Recentes</span>
                  </Button>
                  <Button
                    variant="outline"
                    className="h-24 flex flex-col items-center justify-center"
                    onClick={() => {
                      addWidget("events")
                      document.querySelector("[data-state='open']")?.setAttribute("data-state", "closed")
                    }}
                  >
                    <Calendar className="h-8 w-8 mb-2" />
                    <span>Próximos Eventos</span>
                  </Button>
                  <Button
                    variant="outline"
                    className="h-24 flex flex-col items-center justify-center"
                    onClick={() => {
                      addWidget("message")
                      document.querySelector("[data-state='open']")?.setAttribute("data-state", "closed")
                    }}
                  >
                    <MessageSquare className="h-8 w-8 mb-2" />
                    <span>Mensagem do Dia</span>
                  </Button>
                  <Button
                    variant="outline"
                    className="h-24 flex flex-col items-center justify-center"
                    onClick={() => {
                      addWidget("products")
                      document.querySelector("[data-state='open']")?.setAttribute("data-state", "closed")
                    }}
                  >
                    <Package className="h-8 w-8 mb-2" />
                    <span>Progresso dos Produtos</span>
                  </Button>
                  <Button
                    variant="outline"
                    className="h-24 flex flex-col items-center justify-center"
                    onClick={() => {
                      addWidget("transactions")
                      document.querySelector("[data-state='open']")?.setAttribute("data-state", "closed")
                    }}
                  >
                    <LineChart className="h-8 w-8 mb-2" />
                    <span>Transações Recentes</span>
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {widgets.map((widget) => (
            <Card key={widget.id} className="col-span-1">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle>{widget.title}</CardTitle>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-4 w-4"
                      >
                        <circle cx="12" cy="12" r="1" />
                        <circle cx="12" cy="5" r="1" />
                        <circle cx="12" cy="19" r="1" />
                      </svg>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => removeWidget(widget.id)}>Remover Widget</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </CardHeader>
              <CardContent>{renderWidgetContent(widget)}</CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
