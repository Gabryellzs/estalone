"use client"

import { useState } from "react"

import { AppSidebar } from "@/components/app-sidebar"
import DashboardView from "@/components/dashboard-view"
import CalendarView from "@/components/views/calendar-view"
import DailyMessageView from "@/components/views/daily-message-view"
import DiaryView from "@/components/views/diary-view"
import FinancesView from "@/components/views/finances-view"
import MindMapView from "@/components/views/mind-map-view"
import NotesView from "@/components/views/notes-view"
import ProductCreationView from "@/components/views/product-creation-view"
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar"

type ViewType = "dashboard" | "diary" | "notes" | "calendar" | "products" | "message" | "finances" | "mindmap"

export default function Dashboard() {
  const [activeView, setActiveView] = useState<ViewType>("dashboard")

  const renderView = () => {
    switch (activeView) {
      case "dashboard":
        return <DashboardView onViewChange={(view) => setActiveView(view as ViewType)} />
      case "diary":
        return <DiaryView />
      case "notes":
        return <NotesView />
      case "calendar":
        return <CalendarView />
      case "products":
        return <ProductCreationView />
      case "message":
        return <DailyMessageView />
      case "finances":
        return <FinancesView />
      case "mindmap":
        return <MindMapView />
      default:
        return <DashboardView onViewChange={(view) => setActiveView(view as ViewType)} />
    }
  }

  return (
    <SidebarProvider>
      <AppSidebar onViewChange={setActiveView} activeView={activeView} />
      <SidebarInset>
        <div className="h-full overflow-auto">{renderView()}</div>
      </SidebarInset>
    </SidebarProvider>
  )
}
