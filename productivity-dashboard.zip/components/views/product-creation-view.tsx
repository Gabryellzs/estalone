"use client"

import type React from "react"

import { useState } from "react"
import { Clock, Edit, Grid, List, Plus, Search, Trash } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"

// Importe o hook useLocalStorage
import { useLocalStorage } from "@/hooks/use-local-storage"

interface Product {
  id: string
  name: string
  description: string
  features?: string
  targetAudience?: string
  createdAt: string
  color?: string
}

// Cores para os cards de produtos
const CARD_COLORS = [
  "bg-blue-500/10 border-blue-500/30",
  "bg-green-500/10 border-green-500/30",
  "bg-purple-500/10 border-purple-500/30",
  "bg-amber-500/10 border-amber-500/30",
  "bg-rose-500/10 border-rose-500/30",
  "bg-cyan-500/10 border-cyan-500/30",
]

export default function ProductCreationView() {
  // Estados principais
  // Substitua a linha:
  // const [products, setProducts] = useState<Product[]>([])
  // Por:
  const [products, setProducts] = useLocalStorage<Product[]>("products", [])
  // Substitua a linha:
  // const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  // Por:
  const [viewMode, setViewMode] = useLocalStorage<"grid" | "list">("products-view-mode", "grid")
  const [searchQuery, setSearchQuery] = useState("")

  // Estados para criação/edição
  const [isCreating, setIsCreating] = useState(true)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)

  // Estado do formulário
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    features: "",
    targetAudience: "",
  })

  // Manipuladores de formulário
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleEditChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    if (editingProduct) {
      setEditingProduct({ ...editingProduct, [name]: value })
    }
  }

  // Funções CRUD
  const createProduct = () => {
    if (!formData.name || !formData.description) {
      toast({
        title: "Campos obrigatórios",
        description: "Nome e descrição são obrigatórios.",
        variant: "destructive",
      })
      return
    }

    const randomColor = CARD_COLORS[Math.floor(Math.random() * CARD_COLORS.length)]

    const newProduct = {
      id: Date.now().toString(),
      ...formData,
      createdAt: new Date().toLocaleString(),
      color: randomColor,
    }

    setProducts([newProduct, ...products])
    setFormData({
      name: "",
      description: "",
      features: "",
      targetAudience: "",
    })
    setIsCreating(false)

    toast({
      title: "Produto criado",
      description: "Seu produto foi criado com sucesso.",
    })
  }

  const startEditing = (product: Product) => {
    setEditingProduct(product)
    setIsEditDialogOpen(true)
  }

  const saveEdit = () => {
    if (!editingProduct) return

    setProducts(
      products.map((product) =>
        product.id === editingProduct.id
          ? {
              ...editingProduct,
              createdAt: `${editingProduct.createdAt.split("(")[0]} (Editado: ${new Date().toLocaleTimeString()})`,
            }
          : product,
      ),
    )

    setIsEditDialogOpen(false)
    setEditingProduct(null)

    toast({
      title: "Produto atualizado",
      description: "As alterações foram salvas com sucesso.",
    })
  }

  const deleteProduct = (id: string) => {
    setProducts(products.filter((product) => product.id !== id))

    toast({
      title: "Produto excluído",
      description: "O produto foi removido com sucesso.",
    })
  }

  // Filtrar produtos com base na pesquisa
  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Renderização condicional baseada no estado isCreating
  if (isCreating) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <h1 className="text-3xl font-bold">Criação de Produto</h1>

        <Card>
          <CardHeader>
            <CardTitle>Novo Produto</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome do Produto *</Label>
              <Input
                id="name"
                name="name"
                placeholder="Digite o nome do produto"
                value={formData.name}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descrição *</Label>
              <Textarea
                id="description"
                name="description"
                placeholder="Descreva seu produto..."
                className="min-h-[100px]"
                value={formData.description}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="features">Características e Funcionalidades</Label>
              <Textarea
                id="features"
                name="features"
                placeholder="Liste as principais características..."
                className="min-h-[100px]"
                value={formData.features}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="targetAudience">Público-Alvo</Label>
              <Textarea
                id="targetAudience"
                name="targetAudience"
                placeholder="Descreva o público-alvo..."
                className="min-h-[100px]"
                value={formData.targetAudience}
                onChange={handleChange}
              />
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            {products.length > 0 && (
              <Button variant="outline" onClick={() => setIsCreating(false)}>
                Cancelar
              </Button>
            )}
            <Button onClick={createProduct}>
              <Plus className="mr-2 h-4 w-4" />
              Criar Produto
            </Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  // Tela de galeria de produtos
  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-3xl font-bold">Meus Produtos</h1>

        <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar produtos..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-2">
            <Tabs defaultValue={viewMode} onValueChange={(v) => setViewMode(v as "grid" | "list")}>
              <TabsList>
                <TabsTrigger value="grid">
                  <Grid className="h-4 w-4 mr-1" />
                  Grade
                </TabsTrigger>
                <TabsTrigger value="list">
                  <List className="h-4 w-4 mr-1" />
                  Lista
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>
      </div>

      {filteredProducts.length === 0 && searchQuery ? (
        <Card>
          <CardContent className="p-6 text-center text-muted-foreground">
            Nenhum produto encontrado para "{searchQuery}".
          </CardContent>
        </Card>
      ) : (
        <>
          {viewMode === "grid" ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {/* Card para adicionar novo produto */}
              <Card
                className="border-dashed cursor-pointer hover:border-primary/50 transition-colors h-full flex flex-col justify-center items-center"
                onClick={() => setIsCreating(true)}
              >
                <CardContent className="flex flex-col items-center justify-center p-6 h-full">
                  <div className="rounded-full bg-primary/10 p-6 mb-4">
                    <Plus className="h-10 w-10 text-primary" />
                  </div>
                  <h3 className="text-xl font-medium">Novo Produto</h3>
                  <p className="text-muted-foreground text-center mt-2">Clique para criar um novo produto</p>
                </CardContent>
              </Card>

              {/* Cards de produtos */}
              {filteredProducts.map((product) => (
                <Card key={product.id} className={`shadow-md ${product.color} h-full flex flex-col`}>
                  <CardHeader className="pb-2">
                    <CardTitle className="line-clamp-2">{product.name}</CardTitle>
                    <p className="text-sm text-muted-foreground flex items-center">
                      <Clock className="mr-1 h-3 w-3" />
                      {product.createdAt.split("(")[0]}
                    </p>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <p className="line-clamp-4 whitespace-pre-wrap">{product.description}</p>
                  </CardContent>
                  <CardFooter className="flex justify-end space-x-2">
                    <Button variant="outline" size="sm" onClick={() => startEditing(product)}>
                      <Edit className="mr-1 h-4 w-4" />
                      Editar
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => deleteProduct(product.id)}>
                      <Trash className="mr-1 h-4 w-4" />
                      Excluir
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {/* Botão para adicionar novo produto na visualização de lista */}
              <Card
                className="border-dashed cursor-pointer hover:border-primary/50 transition-colors"
                onClick={() => setIsCreating(true)}
              >
                <CardContent className="flex items-center p-4">
                  <div className="rounded-full bg-primary/10 p-3 mr-4">
                    <Plus className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium">Novo Produto</h3>
                    <p className="text-muted-foreground">Clique para criar um novo produto</p>
                  </div>
                </CardContent>
              </Card>

              {/* Lista de produtos */}
              {filteredProducts.map((product) => (
                <Card key={product.id} className={`shadow-md ${product.color}`}>
                  <CardContent className="p-4">
                    <div className="flex flex-col sm:flex-row justify-between">
                      <div className="space-y-2 mb-4 sm:mb-0">
                        <h3 className="text-lg font-medium">{product.name}</h3>
                        <p className="text-sm text-muted-foreground flex items-center">
                          <Clock className="mr-1 h-3 w-3" />
                          {product.createdAt.split("(")[0]}
                        </p>
                        <p className="line-clamp-2 whitespace-pre-wrap">{product.description}</p>
                      </div>
                      <div className="flex sm:flex-col justify-end space-x-2 sm:space-x-0 sm:space-y-2">
                        <Button variant="outline" size="sm" onClick={() => startEditing(product)}>
                          <Edit className="mr-1 h-4 w-4" />
                          Editar
                        </Button>
                        <Button variant="destructive" size="sm" onClick={() => deleteProduct(product.id)}>
                          <Trash className="mr-1 h-4 w-4" />
                          Excluir
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </>
      )}

      {/* Diálogo de edição */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Editar Produto</DialogTitle>
          </DialogHeader>

          {editingProduct && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Nome do Produto *</Label>
                <Input id="edit-name" name="name" value={editingProduct.name} onChange={handleEditChange} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-description">Descrição *</Label>
                <Textarea
                  id="edit-description"
                  name="description"
                  className="min-h-[100px]"
                  value={editingProduct.description}
                  onChange={handleEditChange}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-features">Características e Funcionalidades</Label>
                <Textarea
                  id="edit-features"
                  name="features"
                  className="min-h-[100px]"
                  value={editingProduct.features || ""}
                  onChange={handleEditChange}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-targetAudience">Público-Alvo</Label>
                <Textarea
                  id="edit-targetAudience"
                  name="targetAudience"
                  className="min-h-[100px]"
                  value={editingProduct.targetAudience || ""}
                  onChange={handleEditChange}
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={saveEdit}>Salvar Alterações</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
