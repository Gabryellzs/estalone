"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

// Importe o hook useLocalStorage
import { useLocalStorage } from "@/hooks/use-local-storage"

interface CalendarNote {
  id: string
  date: string
  title: string
  content: string
}

export default function CalendarView() {
  const [currentDate, setCurrentDate] = useState(new Date())
  // Substitua as linhas:
  // const [events, setEvents] = useState<{ date: string; title: string }[]>([])
  // const [notes, setNotes] = useState<CalendarNote[]>([])

  // Por:
  const [events, setEvents] = useLocalStorage<{ date: string; title: string }[]>("calendar-events", [])
  const [notes, setNotes] = useLocalStorage<CalendarNote[]>("calendar-notes", [])
  const [newEventTitle, setNewEventTitle] = useState("")

  // Estado para o diálogo de anotações
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [selectedDay, setSelectedDay] = useState<number | null>(null)
  const [noteTitle, setNoteTitle] = useState("")
  const [noteContent, setNoteContent] = useState("")
  const [viewingNotes, setViewingNotes] = useState<CalendarNote[]>([])
  const [isViewMode, setIsViewMode] = useState(false)

  const monthNames = [
    "Janeiro",
    "Fevereiro",
    "Março",
    "Abril",
    "Maio",
    "Junho",
    "Julho",
    "Agosto",
    "Setembro",
    "Outubro",
    "Novembro",
    "Dezembro",
  ]

  const daysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate()
  }

  const firstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay()
  }

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))
  }

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))
  }

  const addEvent = (day: number) => {
    if (!newEventTitle.trim()) return

    const dateStr = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${day}`
    const newEvent = {
      date: dateStr,
      title: newEventTitle,
    }

    setEvents([...events, newEvent])
    setNewEventTitle("")
  }

  const getEventsForDay = (day: number) => {
    const dateStr = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${day}`
    return events.filter((event) => event.date === dateStr)
  }

  const getNotesForDay = (day: number) => {
    const dateStr = formatDateString(day)
    return notes.filter((note) => note.date === dateStr)
  }

  const formatDateString = (day: number) => {
    return `${currentDate.getFullYear()}-${(currentDate.getMonth() + 1).toString().padStart(2, "0")}-${day.toString().padStart(2, "0")}`
  }

  const handleDayClick = (day: number) => {
    setSelectedDay(day)
    const dayNotes = getNotesForDay(day)

    if (dayNotes.length > 0) {
      setViewingNotes(dayNotes)
      setIsViewMode(true)
    } else {
      setIsViewMode(false)
    }

    setNoteTitle("")
    setNoteContent("")
    setIsDialogOpen(true)
  }

  const handleAddNote = () => {
    if (!noteTitle.trim() || selectedDay === null) return

    const newNote: CalendarNote = {
      id: Date.now().toString(),
      date: formatDateString(selectedDay),
      title: noteTitle,
      content: noteContent,
    }

    setNotes([...notes, newNote])
    setNoteTitle("")
    setNoteContent("")
    setIsDialogOpen(false)
  }

  const handleCreateNewNote = () => {
    setIsViewMode(false)
    setNoteTitle("")
    setNoteContent("")
  }

  const renderCalendar = () => {
    const year = currentDate.getFullYear()
    const month = currentDate.getMonth()
    const days = daysInMonth(year, month)
    const firstDay = firstDayOfMonth(year, month)

    const calendarDays = []

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      calendarDays.push(<div key={`empty-${i}`} className="h-24 border border-border/50 bg-muted/20"></div>)
    }

    const today = new Date()
    const isToday = (day: number) => {
      return (
        today.getDate() === day &&
        today.getMonth() === currentDate.getMonth() &&
        today.getFullYear() === currentDate.getFullYear()
      )
    }

    // Add cells for each day of the month
    for (let day = 1; day <= days; day++) {
      const dayEvents = getEventsForDay(day)
      const dayNotes = getNotesForDay(day)
      const hasNotes = dayNotes.length > 0

      calendarDays.push(
        <div
          key={day}
          className={`h-24 border border-border/50 p-1 relative cursor-pointer hover:bg-muted/30 transition-colors ${
            hasNotes ? "border-primary/50 bg-primary/5" : ""
          } ${isToday(day) ? "ring-2 ring-primary ring-offset-2 ring-offset-background" : ""}`}
          onClick={() => handleDayClick(day)}
        >
          <div className="font-medium flex justify-between items-center">
            <span>{day}</span>
            {hasNotes && <div className="w-2 h-2 rounded-full bg-primary mr-1"></div>}
          </div>

          {dayEvents.map((event, index) => (
            <div key={index} className="text-xs p-1 mt-1 bg-primary/20 rounded truncate">
              {event.title}
            </div>
          ))}

          {hasNotes && (
            <div className="absolute bottom-1 right-1">
              <Button variant="ghost" size="icon" className="h-5 w-5">
                <Plus className="h-3 w-3" />
              </Button>
            </div>
          )}
        </div>,
      )
    }

    return calendarDays
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold">Calendário</h1>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle>
            {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="icon" onClick={prevMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={nextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-1">
            {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((day) => (
              <div key={day} className="text-center font-medium py-2">
                {day}
              </div>
            ))}
            {renderCalendar()}
          </div>
        </CardContent>
      </Card>

      {/* Diálogo para adicionar/visualizar anotações */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>
              {isViewMode
                ? `Anotações para ${selectedDay} de ${monthNames[currentDate.getMonth()]}`
                : `Adicionar anotação para ${selectedDay} de ${monthNames[currentDate.getMonth()]}`}
            </DialogTitle>
          </DialogHeader>

          {isViewMode ? (
            <div className="space-y-4">
              {viewingNotes.map((note) => (
                <Card key={note.id}>
                  <CardHeader className="py-3">
                    <CardTitle className="text-base">{note.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="whitespace-pre-wrap text-sm">{note.content}</p>
                  </CardContent>
                </Card>
              ))}
              <Button onClick={handleCreateNewNote} className="w-full">
                Adicionar Nova Anotação
              </Button>
            </div>
          ) : (
            <>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="note-title">Título</Label>
                  <Input
                    id="note-title"
                    value={noteTitle}
                    onChange={(e) => setNoteTitle(e.target.value)}
                    placeholder="Título da anotação"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="note-content">Conteúdo</Label>
                  <Textarea
                    id="note-content"
                    value={noteContent}
                    onChange={(e) => setNoteContent(e.target.value)}
                    placeholder="Conteúdo da anotação..."
                    className="min-h-[150px]"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleAddNote}>Salvar Anotação</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
