"use client"

import { useState } from "react"
import { ArrowDownCircle, ArrowUpCircle, Clock, DollarSign, Edit, Save, Trash } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"

// Importe o hook useLocalStorage
import { useLocalStorage } from "@/hooks/use-local-storage"

interface Transaction {
  id: string
  type: "income" | "expense"
  amount: number
  description: string
  date: string
}

export default function FinancesView() {
  // Substitua a linha:
  // const [transactions, setTransactions] = useState<Transaction[]>([])

  // Por:
  const [transactions, setTransactions] = useLocalStorage<Transaction[]>("finance-transactions", [])
  const [type, setType] = useState<"income" | "expense">("income")
  const [amount, setAmount] = useState("")
  const [description, setDescription] = useState("")

  // Estados para edição
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editType, setEditType] = useState<"income" | "expense">("income")
  const [editAmount, setEditAmount] = useState("")
  const [editDescription, setEditDescription] = useState("")

  // Estado para diálogo de confirmação
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false)

  const addTransaction = () => {
    if (!amount || !description) return

    const newTransaction = {
      id: Date.now().toString(),
      type,
      amount: Number.parseFloat(amount),
      description,
      date: new Date().toLocaleDateString(),
    }

    setTransactions([newTransaction, ...transactions])
    setAmount("")
    setDescription("")

    toast({
      title: "Transação adicionada",
      description: `${type === "income" ? "Receita" : "Despesa"} de ${formatCurrency(Number.parseFloat(amount))} adicionada com sucesso.`,
    })
  }

  const startEditing = (transaction: Transaction) => {
    setEditingId(transaction.id)
    setEditType(transaction.type)
    setEditAmount(transaction.amount.toString())
    setEditDescription(transaction.description)
  }

  const saveEdit = (id: string) => {
    if (!editAmount || !editDescription) return

    setTransactions(
      transactions.map((transaction) =>
        transaction.id === id
          ? {
              ...transaction,
              type: editType,
              amount: Number.parseFloat(editAmount),
              description: editDescription,
              date: `${transaction.date} (Editado: ${new Date().toLocaleTimeString()})`,
            }
          : transaction,
      ),
    )

    setEditingId(null)

    toast({
      title: "Transação atualizada",
      description: "A transação foi atualizada com sucesso.",
    })
  }

  const cancelEdit = () => {
    setEditingId(null)
  }

  const deleteTransaction = (id: string) => {
    setTransactions(transactions.filter((transaction) => transaction.id !== id))

    toast({
      title: "Transação excluída",
      description: "A transação foi excluída com sucesso.",
    })
  }

  const clearAllTransactions = () => {
    setTransactions([])
    setIsConfirmDialogOpen(false)

    toast({
      title: "Todas as transações foram excluídas",
      description: "Todas as transações foram removidas do histórico.",
      variant: "destructive",
    })
  }

  const calculateBalance = () => {
    return transactions.reduce((total, transaction) => {
      return transaction.type === "income" ? total + transaction.amount : total - transaction.amount
    }, 0)
  }

  const calculateIncome = () => {
    return transactions.filter((t) => t.type === "income").reduce((total, t) => total + t.amount, 0)
  }

  const calculateExpenses = () => {
    return transactions.filter((t) => t.type === "expense").reduce((total, t) => total + t.amount, 0)
  }

  const formatCurrency = (value: number) => {
    return value.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
    })
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Financeiro</h1>

        {transactions.length > 0 && (
          <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="destructive">Limpar Tudo</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Confirmar exclusão</DialogTitle>
                <DialogDescription>
                  Tem certeza que deseja excluir todas as transações? Esta ação não pode ser desfeita.
                </DialogDescription>
              </DialogHeader>
              <DialogFooter className="flex space-x-2 justify-end">
                <Button variant="outline" onClick={() => setIsConfirmDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button variant="destructive" onClick={clearAllTransactions}>
                  Sim, excluir tudo
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-center">Saldo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center items-center">
              <DollarSign className="h-5 w-5 mr-1" />
              <span className={`text-2xl font-bold ${calculateBalance() >= 0 ? "text-green-500" : "text-red-500"}`}>
                {formatCurrency(calculateBalance())}
              </span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-green-500/5 border-green-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-center">Receitas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center items-center">
              <ArrowUpCircle className="h-5 w-5 mr-1 text-green-500" />
              <span className="text-2xl font-bold text-green-500">{formatCurrency(calculateIncome())}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-red-500/5 border-red-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-center">Despesas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center items-center">
              <ArrowDownCircle className="h-5 w-5 mr-1 text-red-500" />
              <span className="text-2xl font-bold text-red-500">{formatCurrency(calculateExpenses())}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Nova Transação</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <RadioGroup
            defaultValue="income"
            className="flex space-x-4"
            onValueChange={(value) => setType(value as "income" | "expense")}
            value={type}
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="income" id="income" />
              <Label htmlFor="income" className="flex items-center">
                <ArrowUpCircle className="h-4 w-4 mr-1 text-green-500" />
                Receita
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="expense" id="expense" />
              <Label htmlFor="expense" className="flex items-center">
                <ArrowDownCircle className="h-4 w-4 mr-1 text-red-500" />
                Despesa
              </Label>
            </div>
          </RadioGroup>

          <div className="space-y-2">
            <Label htmlFor="amount">Valor</Label>
            <Input
              id="amount"
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descrição</Label>
            <Textarea
              id="description"
              placeholder="Descreva a transação..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={addTransaction}>Adicionar Transação</Button>
        </CardFooter>
      </Card>

      <div className="space-y-4">
        <h2 className="text-2xl font-semibold">Histórico de Transações</h2>

        {transactions.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              Nenhuma transação registrada ainda.
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="p-0">
              <div className="divide-y divide-border">
                {transactions.map((transaction) => (
                  <div key={transaction.id} className="p-4">
                    {editingId === transaction.id ? (
                      // Modo de edição
                      <div className="space-y-4">
                        <RadioGroup
                          className="flex space-x-4"
                          onValueChange={(value) => setEditType(value as "income" | "expense")}
                          value={editType}
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="income" id={`edit-income-${transaction.id}`} />
                            <Label htmlFor={`edit-income-${transaction.id}`} className="flex items-center">
                              <ArrowUpCircle className="h-4 w-4 mr-1 text-green-500" />
                              Receita
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="expense" id={`edit-expense-${transaction.id}`} />
                            <Label htmlFor={`edit-expense-${transaction.id}`} className="flex items-center">
                              <ArrowDownCircle className="h-4 w-4 mr-1 text-red-500" />
                              Despesa
                            </Label>
                          </div>
                        </RadioGroup>

                        <div className="space-y-2">
                          <Label htmlFor={`edit-amount-${transaction.id}`}>Valor</Label>
                          <Input
                            id={`edit-amount-${transaction.id}`}
                            type="number"
                            value={editAmount}
                            onChange={(e) => setEditAmount(e.target.value)}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor={`edit-description-${transaction.id}`}>Descrição</Label>
                          <Textarea
                            id={`edit-description-${transaction.id}`}
                            value={editDescription}
                            onChange={(e) => setEditDescription(e.target.value)}
                          />
                        </div>

                        <div className="flex justify-end space-x-2">
                          <Button variant="outline" size="sm" onClick={cancelEdit}>
                            Cancelar
                          </Button>
                          <Button size="sm" onClick={() => saveEdit(transaction.id)}>
                            <Save className="mr-1 h-4 w-4" />
                            Salvar
                          </Button>
                        </div>
                      </div>
                    ) : (
                      // Modo de visualização
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-4">
                          <div
                            className={`rounded-full p-2 ${
                              transaction.type === "income" ? "bg-green-500/20" : "bg-red-500/20"
                            }`}
                          >
                            <DollarSign
                              className={`h-4 w-4 ${transaction.type === "income" ? "text-green-500" : "text-red-500"}`}
                            />
                          </div>
                          <div>
                            <p className="font-medium">{transaction.description}</p>
                            <div className="flex items-center text-xs text-muted-foreground">
                              <Clock className="mr-1 h-3 w-3" />
                              <span>{transaction.date}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <div
                            className={`font-bold ${transaction.type === "income" ? "text-green-500" : "text-red-500"}`}
                          >
                            {transaction.type === "income" ? "+" : "-"} {formatCurrency(transaction.amount)}
                          </div>
                          <div className="flex space-x-1">
                            <Button variant="ghost" size="icon" onClick={() => startEditing(transaction)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => deleteTransaction(transaction.id)}>
                              <Trash className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
