"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Edit, Plus, Save, Trash, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { useLocalStorage } from "@/hooks/use-local-storage"

interface MindMapNode {
  id: string
  title: string
  content: string
  position: { x: number; y: number }
  connections: string[] // IDs dos nós conectados
  color: string
}

export default function MindMapView() {
  // Estado para os nós do mapa mental
  const [nodes, setNodes] = useLocalStorage<MindMapNode[]>("mind-map-nodes", [])

  // Estado para o nó que está sendo editado/criado
  const [editingNode, setEditingNode] = useState<MindMapNode | null>(null)
  const [isCreating, setIsCreating] = useState(false)

  // Estado para o canvas de conexões
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  // Estado para arrastar nós
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })

  // Estado para conexões
  const [connectingNodeId, setConnectingNodeId] = useState<string | null>(null)

  // Cores para os nós
  const NODE_COLORS = [
    "bg-blue-500/10 border-blue-500/30",
    "bg-green-500/10 border-green-500/30",
    "bg-purple-500/10 border-purple-500/30",
    "bg-amber-500/10 border-amber-500/30",
    "bg-rose-500/10 border-rose-500/30",
    "bg-cyan-500/10 border-cyan-500/30",
  ]

  // Função para criar um novo nó
  const createNode = () => {
    setIsCreating(true)
    const randomColor = NODE_COLORS[Math.floor(Math.random() * NODE_COLORS.length)]

    // Posição inicial para o novo nó (centralizado ou com offset se já existirem nós)
    const initialPosition = {
      x: nodes.length ? 100 + Math.random() * 200 : 300,
      y: nodes.length ? 100 + Math.random() * 200 : 200,
    }

    setEditingNode({
      id: Date.now().toString(),
      title: "",
      content: "",
      position: initialPosition,
      connections: [],
      color: randomColor,
    })
  }

  // Função para salvar um nó (novo ou editado)
  const saveNode = () => {
    if (!editingNode) return

    if (!editingNode.title.trim()) {
      toast({
        title: "Título obrigatório",
        description: "Por favor, forneça um título para o nó.",
        variant: "destructive",
      })
      return
    }

    if (isCreating) {
      // Adicionar novo nó
      setNodes([...nodes, editingNode])
      toast({
        title: "Nó criado",
        description: "O nó foi adicionado ao mapa mental.",
      })
    } else {
      // Atualizar nó existente
      setNodes(nodes.map((node) => (node.id === editingNode.id ? editingNode : node)))
      toast({
        title: "Nó atualizado",
        description: "As alterações foram salvas com sucesso.",
      })
    }

    setEditingNode(null)
    setIsCreating(false)
  }

  // Função para editar um nó existente
  const editNode = (node: MindMapNode) => {
    setEditingNode({ ...node })
    setIsCreating(false)
  }

  // Função para excluir um nó
  const deleteNode = (id: string) => {
    // Remover conexões para este nó em outros nós
    const updatedNodes = nodes.map((node) => ({
      ...node,
      connections: node.connections.filter((connId) => connId !== id),
    }))

    // Remover o nó
    setNodes(updatedNodes.filter((node) => node.id !== id))

    toast({
      title: "Nó excluído",
      description: "O nó foi removido do mapa mental.",
    })
  }

  // Função para iniciar o arrasto de um nó
  const startDragging = (e: React.MouseEvent, nodeId: string) => {
    const node = nodes.find((n) => n.id === nodeId)
    if (!node) return

    const rect = (e.target as HTMLElement).getBoundingClientRect()
    setDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    })

    setDraggingNodeId(nodeId)
  }

  // Função para mover um nó durante o arrasto
  const handleMouseMove = (e: MouseEvent) => {
    if (!draggingNodeId || !containerRef.current) return

    const containerRect = containerRef.current.getBoundingClientRect()
    const x = e.clientX - containerRect.left - dragOffset.x
    const y = e.clientY - containerRect.top - dragOffset.y

    setNodes(
      nodes.map((node) => {
        if (node.id === draggingNodeId) {
          return { ...node, position: { x, y } }
        }
        return node
      }),
    )
  }

  // Função para finalizar o arrasto
  const handleMouseUp = () => {
    setDraggingNodeId(null)
  }

  // Função para iniciar uma conexão
  const startConnection = (nodeId: string) => {
    setConnectingNodeId(nodeId)
    toast({
      title: "Criando conexão",
      description: "Clique em outro nó para conectá-lo.",
    })
  }

  // Função para completar uma conexão
  const completeConnection = (targetNodeId: string) => {
    if (!connectingNodeId || connectingNodeId === targetNodeId) {
      setConnectingNodeId(null)
      return
    }

    // Verificar se a conexão já existe
    const sourceNode = nodes.find((n) => n.id === connectingNodeId)
    if (sourceNode?.connections.includes(targetNodeId)) {
      setConnectingNodeId(null)
      toast({
        title: "Conexão já existe",
        description: "Estes nós já estão conectados.",
        variant: "destructive",
      })
      return
    }

    // Adicionar conexão
    setNodes(
      nodes.map((node) => {
        if (node.id === connectingNodeId) {
          return { ...node, connections: [...node.connections, targetNodeId] }
        }
        return node
      }),
    )

    toast({
      title: "Conexão criada",
      description: "Os nós foram conectados com sucesso.",
    })

    setConnectingNodeId(null)
  }

  // Função para remover uma conexão
  const removeConnection = (sourceId: string, targetId: string) => {
    setNodes(
      nodes.map((node) => {
        if (node.id === sourceId) {
          return { ...node, connections: node.connections.filter((id) => id !== targetId) }
        }
        return node
      }),
    )

    toast({
      title: "Conexão removida",
      description: "A conexão foi removida com sucesso.",
    })
  }

  // Desenhar as conexões no canvas
  useEffect(() => {
    const canvas = canvasRef.current
    const container = containerRef.current
    if (!canvas || !container || nodes.length === 0) return

    // Ajustar o tamanho do canvas ao container
    canvas.width = container.clientWidth
    canvas.height = container.clientHeight

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Limpar o canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Desenhar as conexões
    ctx.strokeStyle = "rgba(100, 116, 139, 0.6)"
    ctx.lineWidth = 2

    nodes.forEach((sourceNode) => {
      sourceNode.connections.forEach((targetId) => {
        const targetNode = nodes.find((n) => n.id === targetId)
        if (!targetNode) return

        // Calcular pontos de início e fim (centro dos nós)
        const startX = sourceNode.position.x + 150
        const startY = sourceNode.position.y + 75
        const endX = targetNode.position.x + 150
        const endY = targetNode.position.y + 75

        // Desenhar a linha
        ctx.beginPath()
        ctx.moveTo(startX, startY)
        ctx.lineTo(endX, endY)
        ctx.stroke()

        // Desenhar seta na ponta
        const angle = Math.atan2(endY - startY, endX - startX)
        const arrowSize = 10

        ctx.beginPath()
        ctx.moveTo(endX, endY)
        ctx.lineTo(endX - arrowSize * Math.cos(angle - Math.PI / 6), endY - arrowSize * Math.sin(angle - Math.PI / 6))
        ctx.lineTo(endX - arrowSize * Math.cos(angle + Math.PI / 6), endY - arrowSize * Math.sin(angle + Math.PI / 6))
        ctx.closePath()
        ctx.fillStyle = "rgba(100, 116, 139, 0.6)"
        ctx.fill()
      })
    })
  }, [nodes])

  // Adicionar e remover event listeners para o arrasto
  useEffect(() => {
    if (draggingNodeId) {
      window.addEventListener("mousemove", handleMouseMove)
      window.addEventListener("mouseup", handleMouseUp)
    }

    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("mouseup", handleMouseUp)
    }
  }, [draggingNodeId, dragOffset, nodes])

  // Renderizar o formulário de edição/criação
  if (editingNode) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">{isCreating ? "Criar Novo Nó" : "Editar Nó"}</h1>
          <Button variant="ghost" size="icon" onClick={() => setEditingNode(null)}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Informações do Nó</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="title" className="text-sm font-medium">
                Título *
              </label>
              <Input
                id="title"
                value={editingNode.title}
                onChange={(e) => setEditingNode({ ...editingNode, title: e.target.value })}
                placeholder="Digite o título do nó"
              />
            </div>

            <div className="space-y-2">
              <label htmlFor="content" className="text-sm font-medium">
                Conteúdo
              </label>
              <Textarea
                id="content"
                value={editingNode.content}
                onChange={(e) => setEditingNode({ ...editingNode, content: e.target.value })}
                placeholder="Digite o conteúdo do nó"
                className="min-h-[150px]"
              />
            </div>
          </CardContent>
          <CardFooter className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => setEditingNode(null)}>
              Cancelar
            </Button>
            <Button onClick={saveNode}>
              <Save className="mr-2 h-4 w-4" />
              Salvar
            </Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  // Renderizar o mapa mental
  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Mapa Mental</h1>
        <div className="flex space-x-2">
          {connectingNodeId && (
            <Button variant="outline" onClick={() => setConnectingNodeId(null)}>
              Cancelar Conexão
            </Button>
          )}
          <Button onClick={createNode}>
            <Plus className="mr-2 h-4 w-4" />
            Novo Nó
          </Button>
        </div>
      </div>

      {nodes.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="rounded-full bg-primary/10 p-6 mb-4">
              <Plus className="h-10 w-10 text-primary" />
            </div>
            <h3 className="text-xl font-medium mb-2">Seu Mapa Mental está vazio</h3>
            <p className="text-muted-foreground text-center max-w-md mb-6">
              Adicione nós para começar a criar seu mapa mental e organizar suas ideias.
            </p>
            <Button onClick={createNode}>
              <Plus className="mr-2 h-4 w-4" />
              Criar Primeiro Nó
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div
          ref={containerRef}
          className="relative border rounded-lg bg-muted/20 h-[600px] overflow-auto"
          style={{ cursor: connectingNodeId ? "crosshair" : "default" }}
        >
          <canvas ref={canvasRef} className="absolute top-0 left-0 w-full h-full pointer-events-none" />

          {nodes.map((node) => (
            <div
              key={node.id}
              className={`absolute w-[300px] ${node.color}`}
              style={{
                left: `${node.position.x}px`,
                top: `${node.position.y}px`,
              }}
              onClick={() => connectingNodeId && completeConnection(node.id)}
            >
              <Card className="shadow-md">
                <div
                  className="absolute top-0 left-0 right-0 h-6 cursor-move bg-transparent"
                  onMouseDown={(e) => startDragging(e, node.id)}
                />
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{node.title}</CardTitle>
                </CardHeader>
                {node.content && (
                  <CardContent className="py-2">
                    <p className="text-sm whitespace-pre-wrap">{node.content}</p>
                  </CardContent>
                )}
                <CardFooter className="flex justify-end space-x-1 pt-2">
                  <Button variant="ghost" size="icon" onClick={() => startConnection(node.id)}>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                      <polyline points="15 3 21 3 21 9" />
                      <line x1="10" y1="14" x2="21" y2="3" />
                    </svg>
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => editNode(node)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => deleteNode(node.id)}>
                    <Trash className="h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            </div>
          ))}

          {/* Lista de conexões para gerenciamento */}
          {nodes.length > 1 && (
            <div className="absolute bottom-4 right-4 w-64">
              <Card>
                <CardHeader className="py-3">
                  <CardTitle className="text-sm">Conexões</CardTitle>
                </CardHeader>
                <CardContent className="py-2 px-3 max-h-40 overflow-y-auto">
                  {nodes
                    .flatMap((sourceNode) =>
                      sourceNode.connections.map((targetId) => {
                        const targetNode = nodes.find((n) => n.id === targetId)
                        if (!targetNode) return null

                        return (
                          <div
                            key={`${sourceNode.id}-${targetId}`}
                            className="flex justify-between items-center text-xs py-1"
                          >
                            <span>
                              {sourceNode.title} → {targetNode.title}
                            </span>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-5 w-5"
                              onClick={() => removeConnection(sourceNode.id, targetId)}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                        )
                      }),
                    )
                    .filter(Boolean)}

                  {!nodes.some((node) => node.connections.length > 0) && (
                    <p className="text-xs text-muted-foreground">
                      Nenhuma conexão criada. Use o botão de conexão nos nós para criar conexões.
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
