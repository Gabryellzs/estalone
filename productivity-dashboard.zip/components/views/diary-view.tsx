"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Textarea } from "@/components/ui/textarea"

// Importe o hook useLocalStorage
import { useLocalStorage } from "@/hooks/use-local-storage"

// Dias da semana em português
const diasDaSemana = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]

// Interface para as entradas do diário
interface DiaryEntry {
  id: string
  content: string
  date: string
}

// Interface para as entradas organizadas por dia da semana
interface WeeklyEntries {
  [key: string]: DiaryEntry[]
}

export default function DiaryView() {
  // Estado para o dia selecionado atualmente
  const [selectedDay, setSelectedDay] = useState<string>(
    diasDaSemana[new Date().getDay() === 0 ? 6 : new Date().getDay() - 1],
  )

  // Estado para o conteúdo da entrada atual
  const [entry, setEntry] = useState("")

  // Estado para as entradas salvas, organizadas por dia da semana
  const [weeklyEntries, setWeeklyEntries] = useLocalStorage<WeeklyEntries>(
    "diary-entries",
    diasDaSemana.reduce((acc, day) => {
      acc[day] = []
      return acc
    }, {} as WeeklyEntries),
  )

  // Função para salvar uma entrada no dia selecionado
  const saveEntry = () => {
    if (!entry.trim()) return

    const newEntry = {
      id: Date.now().toString(),
      content: entry,
      date: new Date().toLocaleString(),
    }

    setWeeklyEntries((prev) => ({
      ...prev,
      [selectedDay]: [newEntry, ...prev[selectedDay]],
    }))

    setEntry("")
  }

  // Função para selecionar um dia da semana
  const selectDay = (day: string) => {
    setSelectedDay(day)
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold">Diário</h1>

      {/* Grid de dias da semana */}
      <div className="grid grid-cols-7 gap-2">
        {diasDaSemana.map((dia) => (
          <Card
            key={dia}
            className={`cursor-pointer transition-all ${
              selectedDay === dia ? "border-primary bg-primary/5" : "hover:border-primary/50"
            }`}
            onClick={() => selectDay(dia)}
          >
            <CardContent className="p-4 text-center">
              <h3 className="font-medium">{dia}</h3>
              <div className="text-xs text-muted-foreground mt-1">
                {weeklyEntries[dia].length > 0
                  ? `${weeklyEntries[dia].length} ${weeklyEntries[dia].length === 1 ? "entrada" : "entradas"}`
                  : "Sem entradas"}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Área de entrada para o dia selecionado */}
      <Card>
        <CardHeader>
          <CardTitle>Nova Entrada para {selectedDay}</CardTitle>
          <CardDescription>Registre seus pensamentos para {selectedDay}</CardDescription>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder={`Escreva aqui sua entrada de diário para ${selectedDay}...`}
            className="min-h-[200px]"
            value={entry}
            onChange={(e) => setEntry(e.target.value)}
          />
        </CardContent>
        <CardFooter>
          <Button onClick={saveEntry}>Salvar Entrada</Button>
        </CardFooter>
      </Card>

      {/* Entradas anteriores para o dia selecionado */}
      <div className="space-y-4">
        <h2 className="text-2xl font-semibold">Entradas para {selectedDay}</h2>

        {weeklyEntries[selectedDay].length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              Nenhuma entrada de diário salva para {selectedDay}.
            </CardContent>
          </Card>
        ) : (
          weeklyEntries[selectedDay].map((entry, index) => (
            <Collapsible key={entry.id} className="w-full">
              <Card>
                <CollapsibleTrigger className="w-full text-left">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Entrada {index + 1}</CardTitle>
                      <CardDescription>{entry.date}</CardDescription>
                    </div>
                    <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform duration-200 group-data-[state=open]:rotate-180" />
                  </CardHeader>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <CardContent>
                    <p className="whitespace-pre-wrap">{entry.content}</p>
                  </CardContent>
                </CollapsibleContent>
              </Card>
            </Collapsible>
          ))
        )}
      </div>

      {/* Visão geral de todas as entradas */}
      <div className="space-y-4 mt-8">
        <h2 className="text-2xl font-semibold">Visão Geral da Semana</h2>

        {diasDaSemana.filter((dia) => weeklyEntries[dia].length > 0).length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              Nenhuma entrada de diário salva para esta semana.
            </CardContent>
          </Card>
        ) : (
          diasDaSemana.map(
            (dia) =>
              weeklyEntries[dia].length > 0 && (
                <Collapsible key={dia} className="w-full">
                  <Card>
                    <CollapsibleTrigger className="w-full text-left">
                      <CardHeader className="flex flex-row items-center justify-between">
                        <div>
                          <CardTitle>{dia}</CardTitle>
                          <CardDescription>
                            {weeklyEntries[dia].length} {weeklyEntries[dia].length === 1 ? "entrada" : "entradas"}
                          </CardDescription>
                        </div>
                        <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform duration-200 group-data-[state=open]:rotate-180" />
                      </CardHeader>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <CardContent className="space-y-4">
                        {weeklyEntries[dia].map((entry, index) => (
                          <div key={entry.id} className="border rounded-md p-4">
                            <div className="flex justify-between items-center mb-2">
                              <h4 className="font-medium">Entrada {index + 1}</h4>
                              <span className="text-xs text-muted-foreground">{entry.date}</span>
                            </div>
                            <p className="whitespace-pre-wrap">{entry.content}</p>
                          </div>
                        ))}
                      </CardContent>
                    </CollapsibleContent>
                  </Card>
                </Collapsible>
              ),
          )
        )}
      </div>
    </div>
  )
}
