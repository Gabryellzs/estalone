"use client"

import type React from "react"

import { useState } from "react"
import { Clock, Edit, Grid, List, Plus, Search, Trash } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"

// Importe o hook useLocalStorage
import { useLocalStorage } from "@/hooks/use-local-storage"

interface Note {
  id: string
  title: string
  content: string
  date: string
  color?: string
}

// Cores para os cards de notas
const CARD_COLORS = [
  "bg-blue-500/10 border-blue-500/30",
  "bg-green-500/10 border-green-500/30",
  "bg-purple-500/10 border-purple-500/30",
  "bg-amber-500/10 border-amber-500/30",
  "bg-rose-500/10 border-rose-500/30",
  "bg-cyan-500/10 border-cyan-500/30",
]

export default function NotesView() {
  // Estados principais
  // Substitua a linha:
  // const [notes, setNotes] = useState<Note[]>([])
  const [notes, setNotes] = useLocalStorage<Note[]>("notes", [])

  // Substitua a linha:
  // const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [viewMode, setViewMode] = useLocalStorage<"grid" | "list">("notes-view-mode", "grid")
  const [searchQuery, setSearchQuery] = useState("")

  // Estado para controlar a visualização (formulário ou galeria)
  const [isCreating, setIsCreating] = useState(true)

  // Estado para edição
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingNote, setEditingNote] = useState<Note | null>(null)

  // Estado do formulário
  const [formData, setFormData] = useState({
    title: "",
    content: "",
  })

  // Manipuladores de formulário
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleEditChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    if (editingNote) {
      setEditingNote({ ...editingNote, [name]: value })
    }
  }

  // Funções CRUD
  const createNote = () => {
    if (!formData.title || !formData.content) {
      toast({
        title: "Campos obrigatórios",
        description: "Título e descrição são obrigatórios.",
        variant: "destructive",
      })
      return
    }

    const randomColor = CARD_COLORS[Math.floor(Math.random() * CARD_COLORS.length)]

    const newNote = {
      id: Date.now().toString(),
      title: formData.title,
      content: formData.content,
      date: new Date().toLocaleString(),
      color: randomColor,
    }

    setNotes([newNote, ...notes])
    setFormData({
      title: "",
      content: "",
    })
    setIsCreating(false)

    toast({
      title: "Anotação criada",
      description: "Sua anotação foi criada com sucesso.",
    })
  }

  const startEditing = (note: Note) => {
    setEditingNote(note)
    setIsEditDialogOpen(true)
  }

  const saveEdit = () => {
    if (!editingNote) return

    setNotes(
      notes.map((note) =>
        note.id === editingNote.id
          ? {
              ...editingNote,
              date: `${editingNote.date.split("(")[0]} (Editado: ${new Date().toLocaleTimeString()})`,
            }
          : note,
      ),
    )

    setIsEditDialogOpen(false)
    setEditingNote(null)

    toast({
      title: "Anotação atualizada",
      description: "As alterações foram salvas com sucesso.",
    })
  }

  const deleteNote = (id: string) => {
    setNotes(notes.filter((note) => note.id !== id))

    toast({
      title: "Anotação excluída",
      description: "A anotação foi removida com sucesso.",
    })
  }

  // Filtrar notas com base na pesquisa
  const filteredNotes = notes.filter(
    (note) =>
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.content.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Renderização condicional baseada no estado isCreating
  if (isCreating) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <h1 className="text-3xl font-bold">Anotações do Dia a Dia</h1>

        <Card>
          <CardHeader>
            <CardTitle>Nova Anotação</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Título *</Label>
              <Input
                id="title"
                name="title"
                placeholder="Digite o título da anotação"
                value={formData.title}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="content">Descrição *</Label>
              <Textarea
                id="content"
                name="content"
                placeholder="Digite o conteúdo da anotação..."
                className="min-h-[150px]"
                value={formData.content}
                onChange={handleChange}
              />
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            {notes.length > 0 && (
              <Button variant="outline" onClick={() => setIsCreating(false)}>
                Cancelar
              </Button>
            )}
            <Button onClick={createNote}>
              <Plus className="mr-2 h-4 w-4" />
              Criar Anotação
            </Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  // Tela de galeria de notas
  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-3xl font-bold">Minhas Anotações</h1>

        <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar anotações..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-2">
            <Tabs defaultValue={viewMode} onValueChange={(v) => setViewMode(v as "grid" | "list")}>
              <TabsList>
                <TabsTrigger value="grid">
                  <Grid className="h-4 w-4 mr-1" />
                  Grade
                </TabsTrigger>
                <TabsTrigger value="list">
                  <List className="h-4 w-4 mr-1" />
                  Lista
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>
      </div>

      {filteredNotes.length === 0 && searchQuery ? (
        <Card>
          <CardContent className="p-6 text-center text-muted-foreground">
            Nenhuma anotação encontrada para "{searchQuery}".
          </CardContent>
        </Card>
      ) : (
        <>
          {viewMode === "grid" ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {/* Card para adicionar nova anotação */}
              <Card
                className="border-dashed cursor-pointer hover:border-primary/50 transition-colors h-full flex flex-col justify-center items-center"
                onClick={() => setIsCreating(true)}
              >
                <CardContent className="flex flex-col items-center justify-center p-6 h-full">
                  <div className="rounded-full bg-primary/10 p-6 mb-4">
                    <Plus className="h-10 w-10 text-primary" />
                  </div>
                  <h3 className="text-xl font-medium">Nova Anotação</h3>
                  <p className="text-muted-foreground text-center mt-2">Clique para criar uma nova anotação</p>
                </CardContent>
              </Card>

              {/* Cards de anotações */}
              {filteredNotes.map((note) => (
                <Card key={note.id} className={`shadow-md ${note.color} h-full flex flex-col`}>
                  <CardHeader className="pb-2">
                    <CardTitle className="line-clamp-2">{note.title}</CardTitle>
                    <p className="text-sm text-muted-foreground flex items-center">
                      <Clock className="mr-1 h-3 w-3" />
                      {note.date.split("(")[0]}
                    </p>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <p className="line-clamp-4 whitespace-pre-wrap">{note.content}</p>
                  </CardContent>
                  <CardFooter className="flex justify-end space-x-2">
                    <Button variant="outline" size="sm" onClick={() => startEditing(note)}>
                      <Edit className="mr-1 h-4 w-4" />
                      Editar
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => deleteNote(note.id)}>
                      <Trash className="mr-1 h-4 w-4" />
                      Excluir
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {/* Botão para adicionar nova anotação na visualização de lista */}
              <Card
                className="border-dashed cursor-pointer hover:border-primary/50 transition-colors"
                onClick={() => setIsCreating(true)}
              >
                <CardContent className="flex items-center p-4">
                  <div className="rounded-full bg-primary/10 p-3 mr-4">
                    <Plus className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium">Nova Anotação</h3>
                    <p className="text-muted-foreground">Clique para criar uma nova anotação</p>
                  </div>
                </CardContent>
              </Card>

              {/* Lista de anotações */}
              {filteredNotes.map((note) => (
                <Card key={note.id} className={`shadow-md ${note.color}`}>
                  <CardContent className="p-4">
                    <div className="flex flex-col sm:flex-row justify-between">
                      <div className="space-y-2 mb-4 sm:mb-0">
                        <h3 className="text-lg font-medium">{note.title}</h3>
                        <p className="text-sm text-muted-foreground flex items-center">
                          <Clock className="mr-1 h-3 w-3" />
                          {note.date.split("(")[0]}
                        </p>
                        <p className="line-clamp-2 whitespace-pre-wrap">{note.content}</p>
                      </div>
                      <div className="flex sm:flex-col justify-end space-x-2 sm:space-x-0 sm:space-y-2">
                        <Button variant="outline" size="sm" onClick={() => startEditing(note)}>
                          <Edit className="mr-1 h-4 w-4" />
                          Editar
                        </Button>
                        <Button variant="destructive" size="sm" onClick={() => deleteNote(note.id)}>
                          <Trash className="mr-1 h-4 w-4" />
                          Excluir
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </>
      )}

      {/* Diálogo de edição */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Editar Anotação</DialogTitle>
          </DialogHeader>

          {editingNote && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-title">Título *</Label>
                <Input id="edit-title" name="title" value={editingNote.title} onChange={handleEditChange} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-content">Descrição *</Label>
                <Textarea
                  id="edit-content"
                  name="content"
                  className="min-h-[150px]"
                  value={editingNote.content}
                  onChange={handleEditChange}
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={saveEdit}>Salvar Alterações</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
