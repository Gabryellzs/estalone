"use client"

import { useState } from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"

// Importe o hook useLocalStorage
import { useLocalStorage } from "@/hooks/use-local-storage"

export default function DailyMessageView() {
  const [message, setMessage] = useState("")
  const [savedMessage, setSavedMessage] = useLocalStorage<string>("daily-message", "")
  const [lastUpdated, setLastUpdated] = useLocalStorage<string | null>("daily-message-updated", null)

  const saveMessage = () => {
    if (!message.trim()) return

    setSavedMessage(message)
    setLastUpdated(new Date().toLocaleString())
    setMessage("")
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold">Mensagem do Dia</h1>

      {savedMessage ? (
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader>
            <CardTitle>Sua Mensagem do Dia</CardTitle>
            {lastUpdated && <p className="text-sm text-muted-foreground">Atualizada em: {lastUpdated}</p>}
          </CardHeader>
          <CardContent>
            <p className="text-xl font-medium whitespace-pre-wrap">{savedMessage}</p>
          </CardContent>
          <CardFooter>
            <Button variant="outline" onClick={() => setMessage(savedMessage)}>
              Editar Mensagem
            </Button>
          </CardFooter>
        </Card>
      ) : (
        <Card className="bg-muted/30">
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">Você ainda não definiu uma mensagem do dia.</p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>{savedMessage ? "Atualizar Mensagem do Dia" : "Definir Mensagem do Dia"}</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder="Digite sua mensagem inspiradora ou lembrete para o dia..."
            className="min-h-[150px]"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          />
        </CardContent>
        <CardFooter>
          <Button onClick={saveMessage}>{savedMessage ? "Atualizar Mensagem" : "Salvar Mensagem"}</Button>
        </CardFooter>
      </Card>
    </div>
  )
}
